<?php
    include "Query.php";
    include "Redirect.php";
    class App{
        use Query;
        use Redirect;
    }
?>