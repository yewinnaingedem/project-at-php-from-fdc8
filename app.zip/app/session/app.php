<?php
    $project = "php-fdc8";
    $_SESSION['project-path'] = "http://" . $_SERVER['HTTP_HOST'] . "/" . $project;


    $_SESSION['errors'] = null;
    $_SESSION['old-values'] = null;
?>